﻿namespace KLAConference.Entities
{
    public enum SessionType
    {
        None,
        Talk,
        Break
    }
}
