﻿namespace KLAConference.Entities
{
    public enum TalkType
    {
        None,
        HomeExpert,
        Vignette
    }
}
